var class_transformable_object =
[
    [ "rotate", "class_transformable_object.html#abe64349a3f20ff5ab47a251de68d292c", null ],
    [ "scale", "class_transformable_object.html#ad5de74dceb7387a09c792d53aecf591e", null ],
    [ "translate", "class_transformable_object.html#afe79e7266af3a1b444acb9de26ae8e1d", null ]
];