var searchData=
[
  ['boundaryfill_0',['boundaryFill',['../class_pixel_canvas.html#a764acb628ed7d7ab0037e6c81fafbaaf',1,'PixelCanvas']]],
  ['boundaryfillauto_1',['boundaryFillAuto',['../class_pixel_canvas.html#a23e39409fc7551315fc99cf33b84e788',1,'PixelCanvas']]],
  ['brush_2',['brush',['../class_pixel_canvas.html#a255d7d7121a2ad3eb70c701213a3887a',1,'PixelCanvas']]]
];
