var searchData=
[
  ['image_0',['image',['../class_bitmap_handler.html#aef24b6315b1d94ba4c78dacca0102466',1,'BitmapHandler']]],
  ['inside_1',['inside',['../class_pixel_canvas.html#a2aa7979c86650a1ec139ad40a3d1965c',1,'PixelCanvas']]]
];
