var searchData=
[
  ['rectangle_0',['rectangle',['../class_pixel_canvas.html#ac7a3f31e114319e677f9bfa8c68f0e87',1,'PixelCanvas']]],
  ['remove_1',['remove',['../class_bitmap_handler.html#acf2fa0be1ae7e8db6d1b81045d9797b3',1,'BitmapHandler']]],
  ['render_2',['render',['../class_pixel_canvas.html#a6c0bceb0f244cb375e9fb5f1b9e2a4b2',1,'PixelCanvas']]],
  ['rotate_3',['rotate',['../class_transformable_object.html#abe64349a3f20ff5ab47a251de68d292c',1,'TransformableObject::rotate()'],['../class_line_segment.html#a0c73c45fa21aeeeaedcbf8f3db98a5ea',1,'LineSegment::rotate()'],['../class_player.html#a1f97d49afc245cd24a0d2b9be55e4d6c',1,'Player::rotate()'],['../class_point2_d.html#a9df317f5e778eaef72f820d5254c0f8d',1,'Point2D::rotate()'],['../class_polygon_object.html#aa5e70fefdb72fe2f483d127f3bf5ebb1',1,'PolygonObject::rotate()'],['../namespace_transform2_d.html#a6d04e7500818f3ce8933ab229086833c',1,'Transform2D::rotate()']]],
  ['run_4',['run',['../class_engine.html#a1a210cf30d6bd330b3649439ecd6d6cc',1,'Engine']]]
];
