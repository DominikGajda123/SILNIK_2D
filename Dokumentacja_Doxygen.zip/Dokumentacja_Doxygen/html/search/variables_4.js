var searchData=
[
  ['frame_0',['frame',['../class_player.html#a4af20962be9096bdc5571ee9f9bf3a29',1,'Player']]]
];
