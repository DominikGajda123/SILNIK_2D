var searchData=
[
  ['direction_0',['direction',['../class_player.html#a6d95202b5546ac375bdb75e3fb657d17',1,'Player']]],
  ['dirty_1',['dirty',['../class_pixel_canvas.html#aa14e6861832785c808d77d2a1e402a1e',1,'PixelCanvas']]]
];
