var searchData=
[
  ['color_0',['color',['../class_polygon_object.html#a6266d0c20d049e1524cf03a4db3687d6',1,'PolygonObject']]]
];
