var searchData=
[
  ['save_0',['save',['../class_bitmap_handler.html#ae59dcef935aff49db6306e3bf274b8e2',1,'BitmapHandler::save()'],['../class_pixel_canvas.html#a5c0ddd5e4433d3fc5a710e64d54f599b',1,'PixelCanvas::save()']]],
  ['savefragment_1',['saveFragment',['../class_bitmap_handler.html#a1d9680d7a3861cbf61e02c6bc980ca82',1,'BitmapHandler']]],
  ['scale_2',['scale',['../class_transformable_object.html#ad5de74dceb7387a09c792d53aecf591e',1,'TransformableObject::scale()'],['../class_line_segment.html#aae9788ebdd34e9302ae0c1e3943c35c9',1,'LineSegment::scale()'],['../class_player.html#a76fcf795ae99906a51430cd2639e5507',1,'Player::scale()'],['../class_point2_d.html#af6ae3398ddfb9994da9d831bc3a3badd',1,'Point2D::scale()'],['../class_polygon_object.html#a52c9d44701d1f91da3cc51c3f8c7c39c',1,'PolygonObject::scale()'],['../namespace_transform2_d.html#a8cb1776e0ea77971db2a0b70a2eeefa7',1,'Transform2D::scale()']]],
  ['set_3',['set',['../class_pixel_canvas.html#a02c107f5d7fbf21b177a2677400ca912',1,'PixelCanvas']]],
  ['setend_4',['setEnd',['../class_line_segment.html#a329301cd605c00bbb26049d6a739cfa0',1,'LineSegment']]],
  ['setposition_5',['setPosition',['../class_point2_d.html#afcb3dc1265ed8158d942d723b8823a0a',1,'Point2D']]],
  ['setstart_6',['setStart',['../class_line_segment.html#a15d2d25ebb6ad98aaeb97525178b56d2',1,'LineSegment']]],
  ['setx_7',['setX',['../class_point2_d.html#a94bbf9ed77025478a303659640faf7b4',1,'Point2D']]],
  ['sety_8',['setY',['../class_point2_d.html#a12e8442a30dbb771ce0f941e6ef3c422',1,'Point2D']]]
];
