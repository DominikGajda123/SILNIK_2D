var searchData=
[
  ['texture_0',['texture',['../class_pixel_canvas.html#a173fa56aa5e5f1e83ca4a72c1450d9eb',1,'PixelCanvas']]],
  ['textures_1',['textures',['../class_player.html#a9f868738406ca3aa8b7bcc4a6384c509',1,'Player']]]
];
