var searchData=
[
  ['translate_0',['translate',['../class_transformable_object.html#afe79e7266af3a1b444acb9de26ae8e1d',1,'TransformableObject::translate()'],['../class_line_segment.html#a9dd1bf718735f6b6af6f3e15fee888aa',1,'LineSegment::translate()'],['../class_player.html#a640068d36cf71305a356e1f4acc51c38',1,'Player::translate()'],['../class_point2_d.html#a8a6751244d279951774c302f0be38af3',1,'Point2D::translate()'],['../class_polygon_object.html#a0c4933d1d3cd6ff58562d0691c1b1a94',1,'PolygonObject::translate()'],['../namespace_transform2_d.html#a8c5753ee0dc5aa0b2e734a7f897f477c',1,'Transform2D::translate()']]]
];
