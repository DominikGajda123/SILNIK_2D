var searchData=
[
  ['pixels_0',['pixels',['../class_pixel_canvas.html#a25b2db1ecd8287fadeb5238b7e1d6b2e',1,'PixelCanvas']]],
  ['points_1',['points',['../class_polygon_object.html#afe261b024360499b1c9428d3613ced3d',1,'PolygonObject']]],
  ['position_2',['position',['../class_player.html#a1ee2015e626c8172db50820decf6b81e',1,'Player']]]
];
