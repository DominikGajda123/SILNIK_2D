var searchData=
[
  ['scalefactor_0',['scaleFactor',['../class_player.html#ab2a614536aa3943b546c96e43b53926e',1,'Player']]],
  ['start_1',['start',['../class_line_segment.html#aa9c45270cadd4d67f7427efcc552389b',1,'LineSegment']]]
];
