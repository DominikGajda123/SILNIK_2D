var searchData=
[
  ['updatableobject_0',['UpdatableObject',['../class_updatable_object.html',1,'']]],
  ['update_1',['update',['../class_updatable_object.html#a2fabeffe567a263b7a8a3b29f8fc8a6b',1,'UpdatableObject::update()'],['../class_player.html#abe2902b7decc38472183a08977eeb57f',1,'Player::update()']]]
];
