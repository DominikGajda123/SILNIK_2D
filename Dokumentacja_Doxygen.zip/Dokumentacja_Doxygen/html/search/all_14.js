var searchData=
[
  ['_7egameobject_0',['~GameObject',['../class_game_object.html#a67ae2fa6e7916c799700cd659975d8ea',1,'GameObject']]],
  ['_7espriteobject_1',['~SpriteObject',['../class_sprite_object.html#a9a1b07612369f698451aca2c30caf95a',1,'SpriteObject']]]
];
