var class_bitmap_object =
[
    [ "draw", "class_bitmap_object.html#a66f9725c9ec5e9a2d3832d757af69528", null ]
];