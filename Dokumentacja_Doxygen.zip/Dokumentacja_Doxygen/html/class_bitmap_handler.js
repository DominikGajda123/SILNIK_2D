var class_bitmap_handler =
[
    [ "copyFrom", "class_bitmap_handler.html#aa9b2051fd142646ad04d6bd0c3facd8d", null ],
    [ "create", "class_bitmap_handler.html#addb97316a410a2617e56feb196f4ef3b", null ],
    [ "getImage", "class_bitmap_handler.html#a9597cc426f3f739ca196f5b9d7c9c2fc", null ],
    [ "load", "class_bitmap_handler.html#a1e8f5adcc1387a9bfaf2e1620b2a5167", null ],
    [ "loadFragment", "class_bitmap_handler.html#ab47e4504909a6ceeb5b38090dc5c62c1", null ],
    [ "remove", "class_bitmap_handler.html#acf2fa0be1ae7e8db6d1b81045d9797b3", null ],
    [ "save", "class_bitmap_handler.html#ae59dcef935aff49db6306e3bf274b8e2", null ],
    [ "saveFragment", "class_bitmap_handler.html#a1d9680d7a3861cbf61e02c6bc980ca82", null ],
    [ "image", "class_bitmap_handler.html#aef24b6315b1d94ba4c78dacca0102466", null ]
];