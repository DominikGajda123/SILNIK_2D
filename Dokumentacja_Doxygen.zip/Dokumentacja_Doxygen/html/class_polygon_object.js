var class_polygon_object =
[
    [ "PolygonObject", "class_polygon_object.html#af30fc87ee910bba2681559fcb272531b", null ],
    [ "draw", "class_polygon_object.html#a24366bcf713f6e0357b0864eea56a030", null ],
    [ "rotate", "class_polygon_object.html#aa5e70fefdb72fe2f483d127f3bf5ebb1", null ],
    [ "scale", "class_polygon_object.html#a52c9d44701d1f91da3cc51c3f8c7c39c", null ],
    [ "translate", "class_polygon_object.html#a0c4933d1d3cd6ff58562d0691c1b1a94", null ],
    [ "color", "class_polygon_object.html#a6266d0c20d049e1524cf03a4db3687d6", null ],
    [ "points", "class_polygon_object.html#afe261b024360499b1c9428d3613ced3d", null ]
];