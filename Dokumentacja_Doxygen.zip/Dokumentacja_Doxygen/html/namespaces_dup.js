var namespaces_dup =
[
    [ "Transform2D", "namespace_transform2_d.html", [
      [ "rotate", "namespace_transform2_d.html#a6d04e7500818f3ce8933ab229086833c", null ],
      [ "scale", "namespace_transform2_d.html#a8cb1776e0ea77971db2a0b70a2eeefa7", null ],
      [ "translate", "namespace_transform2_d.html#a8c5753ee0dc5aa0b2e734a7f897f477c", null ]
    ] ]
];