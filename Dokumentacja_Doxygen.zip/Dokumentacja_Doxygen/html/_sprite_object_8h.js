var _sprite_object_8h =
[
    [ "AnimatedObject", "class_animated_object.html", "class_animated_object" ],
    [ "BitmapObject", "class_bitmap_object.html", "class_bitmap_object" ],
    [ "SpriteObject", "class_sprite_object.html", "class_sprite_object" ]
];