var class_updatable_object =
[
    [ "update", "class_updatable_object.html#a2fabeffe567a263b7a8a3b29f8fc8a6b", null ]
];